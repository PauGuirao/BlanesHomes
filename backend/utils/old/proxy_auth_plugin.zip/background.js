
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "dc.oxylabs.io",
                port: parseInt(8005)
            },
            bypassList: ["localhost"]
        }
    };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details, callbackFn) {
            callbackFn({
                authCredentials: {
                    username: "pgc02_BlDXu",
                    password: "XVz33uC+5"
                }
            });
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    