
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "dc.oxylabs.io",
                port: parseInt(8001)
              },
              bypassList: ["localhost"]
            }
          };
    
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    
    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "pgc02_BlDXu",
                    password: "XVz33uC.12345"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    